package com.jasperexample.jasperemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JasperemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(JasperemoApplication.class, args);
	}

}
